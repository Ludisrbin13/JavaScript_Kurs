let total = 0;

function removeFromCart(element) {
	let mainEl = element.closest('.konacan-iznos');
	let price = mainEl.querySelector('p span').innerText;
	let name = mainEl.querySelector('h3').innerText;
	let cards = document.querySelectorAll('.card');
	price = parseInt(price);

	total -= price;
	
	document.querySelector('.total-iznos').innerText = `Total: $${total}`;

	mainEl.remove();

	cards.forEach(function (card) {
		let itemName = card.querySelector('.card h1').innerText;

		if(itemName === name) {
			card.querySelector('.actions button').removeAttribute('disabled');
			card.querySelector('.actions button').innerText = 'Dodaj';
		}

	});
}

function addToCart(element) {

	let mainEl = element.closest('.card');
	let price = mainEl.querySelector('.price').innerText;
	let name = mainEl.querySelector('h1').innerText;
	let worth = document.querySelector('.konacan-iznos-h1');



	price = price.substring(7);
	price = parseInt(price);
	total += price;
	

	worth.innerHTML += `<div class="konacan-iznos">
								<h3>${name}</h3><p> - Cena: $<span>${price}</span> </p>
								<button onclick="removeFromCart(this)" class="remove-item">Ukloni</button>
						</div>`;

	element.innerText = 'Dodato';

	document.querySelector('.total-iznos').innerText = `Total: $${total}`;


	

	element.setAttribute('disabled', 'true');
}