let link = document.querySelector("#link");

link.addEventListener("click", event => {
  event.preventDefault();
  console.log(event.target);
});

let form = document.querySelector("form");

form.addEventListener("submit", event => {
  event.preventDefault();
  console.log("test");
});

let select = document.querySelector("select");

select.addEventListener("change", event => {
  console.log(event.target.value);
});

window.addEventListener("resize", event => {
  console.log(window.innerWidth);
});
