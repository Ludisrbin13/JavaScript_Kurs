let logo = document.querySelector(".lnXdpd");

logo.src = chrome.runtime.getURL("images/cysecor_logo.png");
logo.srcset = chrome.runtime.getURL("images/cysecor_logo.png");
