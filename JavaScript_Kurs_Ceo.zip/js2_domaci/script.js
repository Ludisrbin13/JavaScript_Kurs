let allTotal = 0;

function addToCart(element) {
  let mainEl = element.closest(".card");
  let price = mainEl.querySelector(".price").innerText;
  let remove = mainEl.querySelector(".cart");
  let name = mainEl.querySelector("h3").innerText;
  let cartItems = document.querySelector(".cart-items");

  // Izdvajamo broj
  price = price.substring(1);
  price = parseInt(price);

  allTotal += price;

  cartItems.innerHTML += `<div class="cart-single-item">
                            <strong>${name}</strong> 
                            cena $<span>${price}</span>
                            <button onclick="Brisi(this)">Vrati</button><br>
                          </div>`;

  document.querySelector(".total").innerText = `Total: $${allTotal}`;

  element.innerText = "Dodato";
  element.setAttribute("disabled", "true");
}

function Brisi(element) {
  let mainEl = element.closest(".cart-single-item");
  let price = mainEl.querySelector("span").innerText;
  let name = mainEl.querySelector("strong").innerText;
  let filmovi = document.querySelectorAll(".card");

  price = parseInt(price);
  allTotal -= price;
  document.querySelector(".total").innerText = `Total: $${allTotal}`;
  mainEl.remove();

  filmovi.forEach(function (film) {
    if (film.querySelector(".card h3").innerText === name) {
      film.querySelector(".card button").removeAttribute("disabled");
      film.querySelector(".card button").innerText = "Dodaj";
    }
  });

  console.log(name);
}
