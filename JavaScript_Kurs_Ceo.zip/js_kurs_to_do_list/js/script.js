function Add() {
  let text = document.querySelector("#container").value;

  // input text

  let newElement = document.createElement("div");
  newElement.className = "new-value";

  // button

  newElement.innerText = `${text}`;

  document.querySelector(".container").appendChild(newElement);

  console.log(newElement);
}

function Remove() {}
