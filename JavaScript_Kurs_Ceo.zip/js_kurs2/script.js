function validacija() {
  let input = document.querySelector("#email");
  let value = input.value;

  if (value.includes("@") && value.includes(".")) {
    let pozicijaAt = value.indexOf("@");
    let pozicijaTacka = value.indexOf(".");

    let izmedjuAtTacka = value.substring(pozicijaAt + 1, pozicijaTacka);

    if (izmedjuAtTacka.length > 0) {
      console.log("Dobro je");
    } else {
      console.log("nije dobro");
    }

    console.log(izmedjuAtTacka.length);
  } else {
    console.log("Mail nije validan");
  }
}
