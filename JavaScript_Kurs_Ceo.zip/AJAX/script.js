document.querySelector("#fetchBtn").addEventListener("click", e => {
  e.preventDefault();

  let id = document.querySelector("#userID").value;

  console.log(id);
});

let r = fetch("https://62d6d81751e6e8f06f1469a6.mockapi.io/Users/" + "id")
  .then(response => response.json())
  .then(data => {
    console.log(data);
  })
  .catch(error => {
    alert("Prekinuta veza");
  });
