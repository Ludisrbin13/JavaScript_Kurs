let finished = 1;
let loaded = 0;
let textTag = document.querySelector(".section1 h1");
let text = textTag.textContent;

let splittedText = text.split("");

let border = document.querySelector(".border-line");
let animationWidth = 0;

textTag.innerHTML = "";

splittedText.forEach(i => {
  if (i == " ") {
    i = "&nbsp";
  }

  textTag.innerHTML += `<span>${i}</span>`;
});

const TextAnimation = () => {
  let spans = textTag.querySelectorAll("span");
  let k = 0;
  finished = 0;
  let interval = setInterval(() => {
    let singleSpan = spans[k];

    singleSpan.classList = "fadeMove";

    k++;

    if (k === spans.length) {
      clearInterval(interval);
      finished = 1;
    }
  }, 70);
};

//let spansBack = textTag.querySelectorAll("#fadeMove");

const TextAnimationBack = () => {
  let spans = textTag.querySelectorAll("span");
  let l = 0;
  finished = 0;
  let interval = setInterval(() => {
    let spansBack = spans[l];

    spansBack.classList = "fadeBack";

    l++;

    if (l === spans.length) {
      clearInterval(interval);
      finished = 1;
    }
  }, 70);
};

window.onclick = () => {
  if (finished === 0) return;
  if (loaded === 0) {
    TextAnimation();
    loaded = 1;
  } else {
    TextAnimationBack();
    loaded = 0;
  }
};

window.onkeydown = e => {
  let plus = "NumpadAdd";
  let minus = "NumpadSubtract";
  let code = e.code;
  if (code === plus) {
    animationWidth += 1;
  } else if (code === minus) {
    animationWidth -= 1;
  }

  if (animationWidth >= 100) {
    animationWidth = 100;
  }

  if (animationWidth <= 0) {
    animationWidth = 0;
  }

  border.style.width = animationWidth + "%";
};

/*
window.onscroll = () => {
  imageAnimation();
};

const imageAnimation = () => {
  let sectionForAnimation = document.querySelector(".section2 .images");
  let sectionPosition = sectionForAnimation.getBoundingClientRect().top;
  let screenPosition = this.innerHeight / 1.3;

  let leftImage = document.querySelector(".slideFromLeft");
  let rightImage = document.querySelector(".slideFromRight");

  if (sectionPosition < screenPosition) {
    leftImage.classList.add("animated");
    rightImage.classList.add("animated");
  }
};*/

let btnLeft = document.querySelector(".btnLeft");
let btnRight = document.querySelector(".btnRight");

let leftImage = document.querySelector(".slideFromLeft");
let rightImage = document.querySelector(".slideFromRight");

btnLeft.addEventListener("click", e => {
  leftImage.classList.add("animated");
});

btnRight.addEventListener("click", e => {
  rightImage.classList.add("animated");
});
